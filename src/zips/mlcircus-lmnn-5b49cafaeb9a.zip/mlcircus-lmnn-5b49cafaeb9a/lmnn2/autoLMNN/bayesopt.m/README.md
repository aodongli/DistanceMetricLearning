# README #

BayesOpt.m is a MATLAB implementation of Bayesian Optimization for Hyperparamter optimization with or without constraints. 
Please see the documentation in the repository for details. 


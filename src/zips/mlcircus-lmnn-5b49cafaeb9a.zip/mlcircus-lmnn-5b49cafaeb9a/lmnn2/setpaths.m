addpath(pwd);
addpath([pwd '/helperfunctions']);
addpath([pwd '/mexfunctions/binaries']);
addpath([pwd '/mexfunctions']);
addpath([pwd '/mtrees/binaries']);
addpath([pwd '/mtrees']);
addpath([pwd '/gbrt/binaries']);
addpath([pwd '/gbrt']);

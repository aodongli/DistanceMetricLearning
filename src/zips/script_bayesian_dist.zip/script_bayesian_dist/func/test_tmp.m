function test_tmp(J, x, fname_mean, fname_std, n_active_iter, n_run, n_sub_run,nn)
n_rank = size(x,1);
a = my_mat(x, n_active_iter*n_rank,  n_sub_run*n_run);
tmp = a(:, J(1:nn));
y = mean(tmp, 2);
std_y = std(tmp,0,2);
save_matrix(my_mat(y, n_rank, n_active_iter), 'w', fname_mean);
save_matrix(my_mat(std_y, n_rank, n_active_iter) ,'w', fname_std);


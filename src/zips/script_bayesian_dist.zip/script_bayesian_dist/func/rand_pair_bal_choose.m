function rand_index = rand_pair_bal_choose(delta_vec, n)
a = find(delta_vec==1);
b = find(delta_vec==-1);
a2 = randperm(length(a));
b2 = randperm(length(b));
rand_index = [a(a2(1:n));b(b2(1:n))]';
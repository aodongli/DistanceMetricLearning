function y=rand_index(n,n_select)
tmp=randperm(n);
y =tmp(1:n_select);
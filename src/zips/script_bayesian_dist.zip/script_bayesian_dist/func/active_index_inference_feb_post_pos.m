function inx_return = active_index_inference_feb_post_pos(mean_gamma_vec,var_gamma_mat, w_mat, n_sel)
var_gamma_mat_inv = inv(var_gamma_mat+ 1e-6*eye(size(var_gamma_mat)));
% pos
p_ij_vec_pos = 1./(1+exp(-w_mat*mean_gamma_vec));
q_ij_vec_pos = p_ij_vec_pos.*(1-p_ij_vec_pos);

post_pos_pair_vec = [];
for i= 1:size(w_mat,1)      
    w_mat_pair = (w_mat(i,:))'; % a col
    % compute gamma_vec_star
    cc_inv = inv(q_ij_vec_pos(i)*w_mat_pair*w_mat_pair' + var_gamma_mat_inv+ 1e-6*eye(size(var_gamma_mat)));
    gamma_vec_star_pos  = mean_gamma_vec - p_ij_vec_pos(i)*cc_inv*w_mat_pair;
    % compute q_ij_star
    a = gamma_vec_star_pos'*w_mat_pair;
    q_ij_star_pos  = exp(-a)/((exp(-a)+1)^2);
    % cal l_ij_star
    l_ij_star_pos =log(1+exp(w_mat_pair'*mean_gamma_vec)) + p_ij_vec_pos(i)^2/2* w_mat_pair' *cc_inv*w_mat_pair;
    % cal posterior
    post_pos = exp(-l_ij_star_pos)*sqrt(det(eye(size(var_gamma_mat)) + q_ij_star_pos*var_gamma_mat*w_mat_pair*w_mat_pair'));
    post_pos_pair_vec= [post_pos_pair_vec, post_pos];
end
% select pairs with largest entropy_pair
[x1,x2] = sort(-post_pos_pair_vec);
inx_return = x2(1:n_sel); 
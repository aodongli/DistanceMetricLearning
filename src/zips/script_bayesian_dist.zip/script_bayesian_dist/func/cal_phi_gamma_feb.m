function [var_gamma_mat,mean_gamma_vec] = cal_phi_gamma_feb(delta,gamma0, w_mat,delta_vec, tol_phi_gamma)
n_dim = size(w_mat, 2);
sim_w_mat=w_mat(find((delta_vec==1)),:);
dis_w_mat=w_mat(find((delta_vec==-1)),:);

n_sim_pair= size(sim_w_mat,1);
n_dis_pair= size(dis_w_mat,1);
if n_sim_pair == 0&n_dis_pair ~= 0
    fixed_value= delta* gamma0 * ones(n_dim,1) + 0.5*(sum(dis_w_mat))';
end
if n_sim_pair ~= 0&n_dis_pair == 0
    fixed_value= delta* gamma0 * ones(n_dim,1)- 0.5*(sum(sim_w_mat))';
end
if n_sim_pair ~= 0&n_dis_pair ~= 0
   fixed_value= delta* gamma0 * ones(n_dim,1)- 0.5*(sum(sim_w_mat))'+ 0.5*(sum(dis_w_mat))';
end
sim_pair_epsilen_vec=rand(n_sim_pair,1);
dis_pair_epsilen_vec=rand(n_dis_pair,1);
g=0;
while(1)
    if n_sim_pair ~= 0
        sim_tmp = sim_w_mat'*diag(lambda_func(sim_pair_epsilen_vec))*sim_w_mat;
    else
        sim_tmp = zero(n_dim, n_dim)';
    end
    if n_dis_pair ~= 0
        dis_tmp = dis_w_mat'*diag(lambda_func(dis_pair_epsilen_vec))*dis_w_mat;
    else 
        dis_tmp = zero(n_dim, n_dim)';
    end
    var_gamma_mat = inv(delta.*eye(n_dim)+2.*sim_tmp +2.*dis_tmp);
    mean_gamma_vec = var_gamma_mat * fixed_value;
    if g>1 
        tmp_1 = sum(abs(mean_gamma_vec - mean_gamma_vec_old));
        tmp_2 = sum(sum(abs(var_gamma_mat - var_gamma_mat_old)));
        disp([num2str(tmp_1), '\', num2str(tmp_2)]);
        if tmp_1 < tol_phi_gamma && tmp_2< tol_phi_gamma
            break; 
        end
    end 
    g=g+1;
    mean_gamma_vec_old = mean_gamma_vec;
    var_gamma_mat_old = var_gamma_mat;
    % only keep the positive one
    for i = 1: n_sim_pair
        sim_pair_epsilen_vec(i) = sqrt((sim_w_mat(i, :) * mean_gamma_vec).^2 + sim_w_mat(i,:) * var_gamma_mat * sim_w_mat(i,:)');
    end
    for i = 1: n_dis_pair
        dis_pair_epsilen_vec(i) = sqrt((dis_w_mat(i, :) * mean_gamma_vec).^2 + dis_w_mat(i,:) * var_gamma_mat * dis_w_mat(i,:)');
    end
end

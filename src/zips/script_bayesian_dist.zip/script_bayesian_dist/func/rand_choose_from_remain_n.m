function exist_inx = rand_choose_from_remain_n(total_inx, exist_inx, n)
% row vec
x= total_inx;   x(exist_inx)=[]; 
if isempty(x) == 0
    z = rand_index(length(x),min(n, length(x)));
    exist_inx = [exist_inx,  x(z)];     
end

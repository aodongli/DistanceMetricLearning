function inx_return = active_index_inference_feb(mean_gamma_vec,var_gamma_mat, w_mat, n_sel)
var_gamma_mat = normalize_01(var_gamma_mat);
mean_gamma_vec = normalize_01(mean_gamma_vec);
var_gamma_mat_inv = inv(var_gamma_mat+ 1e-6*eye(size(var_gamma_mat)));
p_ij_vec = exp(-w_mat*mean_gamma_vec)./(1+exp(-w_mat*mean_gamma_vec));
q_ij_vec = p_ij_vec.*(1-p_ij_vec);

entropy_pair_vec = [];
for i= 1:size(w_mat,1)      
    w_mat_pair = (w_mat(i,:))'; % a col
    cc = q_ij_vec(i)*w_mat_pair*w_mat_pair' + var_gamma_mat_inv;    
    cc_inv = inv(cc+ 1e-6*eye(size(cc)));
    tmp = (cc_inv*w_mat_pair);
    gamma_vec_pos_star  = mean_gamma_vec - p_ij_vec(i)*tmp;
    gamma_vec_neg_star  = mean_gamma_vec + (1-p_ij_vec(i))*tmp;
    % cal l_ij_gamma   
    q_ij_ja  = exp(-gamma_vec_pos_star'*w_mat_pair)/((exp(-gamma_vec_pos_star'*w_mat_pair)+1)^2);
    q_ij_jian =exp(-gamma_vec_neg_star'*w_mat_pair)/((exp(-gamma_vec_neg_star'*w_mat_pair)+1)^2);
    cc_new_ja = q_ij_ja*w_mat_pair*w_mat_pair' + var_gamma_mat_inv;    
    cc_new_jian = q_ij_jian*w_mat_pair*w_mat_pair' + var_gamma_mat_inv; 
    l_ij_pos_star =log(1+exp(1+w_mat_pair'*mean_gamma_vec))+ p_ij_vec(i)^2/2* tmp'  *cc_new_ja*tmp;
    l_ij_neg_star =log(1+exp(-w_mat_pair'*mean_gamma_vec))+ (1-p_ij_vec(i))^2/2* tmp'*cc_new_jian*tmp;
    
    % cal posterior
    post_pos = exp(-l_ij_pos_star)*sqrt(det(eye(size(var_gamma_mat)) + q_ij_ja*var_gamma_mat*w_mat_pair*w_mat_pair'));
    post_neg =exp(-l_ij_neg_star)*sqrt(det(eye(size(var_gamma_mat)) + q_ij_jian*var_gamma_mat*w_mat_pair*w_mat_pair'));
    % renormalize
    a = post_pos+post_neg +1e-10;
    post_pos = post_pos/a;
    post_neg = post_neg/a;    
    % entropy 
    entropy_pair_vec =[entropy_pair_vec, -post_pos*log(1e-10+post_pos)-post_neg*log(1e-10+post_neg)];
end
% select pairs with largest entropy_pair
[x1,x2] = sort(-entropy_pair_vec);
inx_return = x2(1:n_sel); 
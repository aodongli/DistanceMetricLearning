eigen_percent=0.999;
[eigen_mat, n_top_eigenK] = cal_eigen_mat_feb(data_mat', eigen_percent);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gamma_vec_rand = load([dir_name, 'gamma_vec_rand']);
gamma_vec_non_bayes_mle_active = load([dir_name, 'gamma_vec_non_bayes_mle_active']);
mean_gamma_vec = load([dir_name, 'mean_gamma_vec']);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
knn_accu_mat_rand = [];
knn_accu_mat_nonb_active =[];
mean_knn_accu_mat_active =[];

for inx_run= 1:n_run
    load_data_by_inx_rand
    w_mat = cal_w_mat_feb(U_search_mat, U_query_mat, eigen_mat, 1:(size(U_search_mat, 2)*size(U_query_mat, 2)), is_nb);  
    for inx_sub_run = 1: n_sub_run
        for j= 1:n_active_iter
            inx = (inx_run - 1)*n_sub_run*n_active_iter + (inx_sub_run -1)*n_active_iter + j;        
            knn_accu_mat_rand = [knn_accu_mat_rand, pred_func_feb(w_mat, gamma_vec_rand(inx, :)', eigen_mat,search_label_vec,query_label_vec, KK_knn)'];
            knn_accu_mat_nonb_active = [knn_accu_mat_nonb_active, pred_func_feb(w_mat, gamma_vec_non_bayes_mle_active(inx,:)', eigen_mat,search_label_vec,query_label_vec, KK_knn)'];
            mean_knn_accu_mat_active = [mean_knn_accu_mat_active, pred_func_feb(w_mat, mean_gamma_vec(inx,:)', eigen_mat,search_label_vec,query_label_vec, KK_knn)'];
        end
    end
end 
mean_std_feb(knn_accu_mat_rand, n_active_iter, [dir_name, 'rand_prec_mean'], [dir_name, 'rand_prec_std'], n_run, n_sub_run);
mean_std_feb(knn_accu_mat_nonb_active, n_active_iter, [dir_name, 'nonb_active_prec_mean'], [dir_name, 'nonb_active_prec_std'], n_run, n_sub_run);
mean_std_feb(mean_knn_accu_mat_active, n_active_iter, [dir_name, 'mean_active_prec_mean'], [dir_name, 'mean_active_prec_std'], n_run, n_sub_run);
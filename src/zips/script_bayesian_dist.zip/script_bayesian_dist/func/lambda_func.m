function y=lambda_func(x)
y=(1/4./x).*tanh(x/2);
function y=step_sum(a,b,step)
% a ---sim_w_mat
% b --- diag(lambda_func(sim_pair_epsilen_vec))
% y= a'*b*a;
[m,n]=size(a);
start=0; 
y=0;
while(start<m)       
    this_step=min(step,m-start);
    index_tmp= (start+1):(start+this_step);
    a_tmp=a(index_tmp,:);
    b_tmp=b(index_tmp,index_tmp);
    y=y+a_tmp'*b_tmp*a_tmp;       
    start=start+this_step;        
end


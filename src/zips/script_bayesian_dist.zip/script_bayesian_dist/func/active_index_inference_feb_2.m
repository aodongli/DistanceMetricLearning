function inx_return = active_index_inference_feb_2(mean_gamma_vec,var_gamma_mat, w_mat, n_sel)
dist_vec = [];
for i= 1:size(w_mat,1)     
    w_mat_pair = (w_mat(i,:))'; % a col
    dist_vec =[dist_vec, (mean_gamma_vec'*w_mat_pair- w_mat_pair'*var_gamma_mat*w_mat_pair*1.5)]; % 
end
% select pairs with largest entropy_pair
[x1,x2] = sort(dist_vec);
inx_return = x2(1:n_sel); 
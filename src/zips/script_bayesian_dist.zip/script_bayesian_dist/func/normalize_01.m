function z = normalize_01_feb(z)
% normalize to [0, 1], col by col
for i = 1:size(z, 2)
    x = z(:, i);
    min_x =min(x);
    max_x =max(x);
    z(:,i) = (x-min_x)/(max_x - min_x);        
end

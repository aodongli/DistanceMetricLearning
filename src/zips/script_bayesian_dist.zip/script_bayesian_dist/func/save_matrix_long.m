function save_matrix_long(M,save_type,path_file_name)
[m,n]=size(M);
fid=fopen(path_file_name,save_type);   
for i=1:m
    fprintf(fid,'%ld ',M(i,:));
    fprintf(fid,'\n');
end
fclose(fid);

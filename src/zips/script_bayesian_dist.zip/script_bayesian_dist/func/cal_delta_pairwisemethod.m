function y = cal_delta_pairwisemethod(train_label_vec, inx_eff)
left_sub=repmat(train_label_vec, length(train_label_vec), 1);
right_sub=vec(repmat(train_label_vec', length(train_label_vec), 1));
y =sign((left_sub==right_sub)-0.5);
y = y(inx_eff);

eigen_percent=0.999; 
[eigen_mat, n_top_eigenK] = cal_eigen_mat_feb(data_mat', eigen_percent);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gamma_vec_rand_fname = [dir_name, 'gamma_vec_rand']; 
gamma_vec_bayes_active_mle_fname = [dir_name, 'gamma_vec_bayes_active_mle'];
mean_gamma_vec_fname = [dir_name, 'mean_gamma_vec'];
gamma_vec_non_bayes_mle_active_fname = [dir_name, 'gamma_vec_non_bayes_mle_active'];
mean_gamma_vec_byabs_pair_selection_fname = [dir_name, 'mean_gamma_vec_byabs_pair_selection'];

for inx_run = 1: n_run 
    load_data_by_inx_rand
    inx_eff = inx_eff_pairwise_func(size(U_train_mat, 2), size(U_train_mat, 2));
    delta_vec = cal_delta_pairwisemethod(train_label_vec, inx_eff); 
    w_mat = cal_w_mat_feb(U_train_mat, U_train_mat, eigen_mat, inx_eff, is_nb);
    for inx_sub_run = 1 : n_sub_run
        active_iter_version_entropy_feb_gamma     
    end
end 

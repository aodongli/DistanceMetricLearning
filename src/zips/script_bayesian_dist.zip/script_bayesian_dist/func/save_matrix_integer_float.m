function save_matrix_integer_float(M,save_type,path_file_name)
[m,n]=size(M);
fid=fopen(path_file_name,save_type);   
for i=1:m
    fprintf(fid,'%d %f ',M(i, 1), M(i,(2:end)));
    fprintf(fid,'\n');
end
fclose(fid);

%function select_index=active_index(w_mat,var_gamma_mat,n_select)
function select_index=active_index(mean_gamma_vec,gamma_vec,w_mat,var_gamma_mat,n_select)
%var_pair_vec= diag(w_mat* var_gamma_mat*w_mat');
% cal var_pair_vec by steps; err: Maximum variable size allowed by the program
% is exceeded.

[var_pair_vec,mean_pair_vec,dist_vec]=cal_covar_dist_pair(mean_gamma_vec,gamma_vec,w_mat,var_gamma_mat);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% sorted by dist: smallest dist
% [y1,y2]=sort(dist_vec);
 [y1,y2]=sort(-var_pair_vec);
%[y1,y2]=sort(var_pair_vec);
%   select_index= y2(1:n_select);
%   select_index=select_index'; % a rol
% % 
mean_pair_vec_sorted=mean_pair_vec(y2);
dist_vec_sorted=dist_vec(y2);
% go through the sored; select those pair whose  dist-mean > mean_total
select_index=[];
mean_total_1= mean(dist_vec);
mean_total_2= mean(mean_pair_vec);
g=1;
while(length(select_index)<n_select)
    if dist_vec_sorted(g)<mean_total_1&&mean_pair_vec_sorted(g)<mean_total_2
       select_index=[select_index,y2(g)];
    end 
    g=g+1;    
end 
select_index=select_index'; % a rol

a=sum(dist_vec(select_index));
a=a/n_select;
b=sum(mean_pair_vec(select_index));
b=b/n_select;



% tmp=y2(1:100);
% [y3,y4]=sort(var_pair_vec(tmp));
% select_index=tmp(y4(1:n_select));
% select_index=select_index'; % a rol
% [y1,y2]=sort(dist_vec); 
% tmp=y2(1:min(50,length(dist_vec)));
% [y3,y4]=sort(-var_pair_vec(tmp));
% select_index=tmp(y4(1:n_select));
% select_index=select_index'; % a rol


function [l_ij_pos, l_ij_neg] = cal_l_ij_pos_neg(aug_w_mat_obj_pair, aug_gamma_pos_vec,aug_gamma_neg_vec, aug_mean_gamma_vec, aug_var_gamma_mat)
a_pos = 1+exp(aug_w_mat_obj_pair' * aug_gamma_pos_vec);
a_neg = 1+exp(-aug_w_mat_obj_pair' * aug_gamma_neg_vec);
if rank(aug_var_gamma_mat)< size(aug_var_gamma_mat,1) 
    b = pinv(aug_var_gamma_mat);
else b = inv(aug_var_gamma_mat);
end
c = (aug_mean_gamma_vec-aug_mean_gamma_vec);
l_ij_pos = log(a_pos)+ 0.5*c'*b*c;
l_ij_neg = log(a_neg)+ 0.5*c'*b*c;

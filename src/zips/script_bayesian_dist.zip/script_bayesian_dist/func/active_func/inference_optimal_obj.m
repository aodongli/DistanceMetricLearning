%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [f,g] = mle_gamma_inference_obj_pos(aug_gamma_vec)
global aug_w_mat_obj_pair;% a vec
global delta_vec_obj_pair; % a scalar
global aug_mean_gamma_vec;
global aug_var_gamma_mat;
% aug_gamma_vec [gamma; \mu]
% minimization problem
[l_ij_pos, l_ij_neg] = cal_l_ij_pos_neg(aug_w_mat_obj_pair, aug_gamma_vec, aug_mean_gamma_vec, aug_var_gamma_mat);
f = l_ij_pos;
[g_ij_pos, g_ij_neg] = cal_g_ij_pos_neg(aug_w_mat_obj_pair, aug_gamma_vec, aug_mean_gamma_vec, aug_var_gamma_mat);
g = g_ij_pos;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [f,g] = mle_gamma_inference_obj_neg(aug_gamma_vec)
global aug_w_mat_obj_pair;% a vec
global delta_vec_obj_pair; % a scalar
global aug_mean_gamma_vec;
global aug_var_gamma_mat;

% aug_gamma_vec [gamma; \mu]
% minimization problem
[l_ij_pos, l_ij_neg] = cal_l_ij_pos_neg(aug_w_mat_obj_pair, aug_gamma_vec, aug_mean_gamma_vec, aug_var_gamma_mat);
f = l_ij_neg;
[g_ij_pos, g_ij_neg] = cal_g_ij_pos_neg(aug_w_mat_obj_pair, aug_gamma_vec, aug_mean_gamma_vec, aug_var_gamma_mat);
g = g_ij_neg;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [g_ij_pos, g_ij_neg] = cal_g_ij_pos_neg(aug_w_mat_obj_pair, aug_gamma_vec, aug_mean_gamma_vec, aug_var_gamma_mat)

a_pos = 1+exp(aug_w_mat_obj_pair' * aug_gamma_vec);
a_neg = 1+exp(-aug_w_mat_obj_pair' * aug_gamma_vec);
if rank(aug_var_gamma_mat)<size(aug_var_gamma_mat,1) 
b = pinv(aug_var_gamma_mat);
else b = inv(aug_var_gamma_mat);
end
c = (aug_mean_gamma_vec-aug_mean_gamma_vec);
g_pos = 1/a_pos*(1-a_pos)*aug_w_mat_obj_pair + b*c; %?
g_neg = -1/a_neg*(1-a_neg)*aug_w_mat_obj_pair + b*c; %? 

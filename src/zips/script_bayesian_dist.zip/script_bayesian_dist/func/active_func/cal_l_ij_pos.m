function l_ij_pos = cal_l_ij_pos(aug_w_mat_obj_pair, aug_gamma_vec, aug_mean_gamma_vec, aug_var_gamma_mat_inv)
a_pos = 1+exp(-aug_w_mat_obj_pair' * aug_gamma_vec);
l_ij_pos = log(a_pos)+ 0.5*(aug_gamma_vec-aug_mean_gamma_vec)'*aug_var_gamma_mat_inv*(aug_gamma_vec-aug_mean_gamma_vec);

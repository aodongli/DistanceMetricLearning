function select_index=active_index_entropy(gamma_vec,w_mat,n_select)

posterior_mat =cal_posterior_naive(gamma_vec,w_mat);
en_pair_vec=cal_entropy_pair_native(posterior_mat);
[y1,y2]=sort(-en_pair_vec);
select_index = y2(1:n_select);

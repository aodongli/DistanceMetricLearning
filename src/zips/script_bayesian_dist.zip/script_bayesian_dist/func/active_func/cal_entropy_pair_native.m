function en_pair_vec=cal_entropy_pair_native(posterior_mat)
% 2* n_pair 
posterior_pos_vec = posterior_mat(1,:);
posterior_neg_vec = posterior_mat(2,:);
en_pair_vec = -posterior_pos_vec.*log(posterior_pos_vec+1e-200) - posterior_neg_vec.*log(posterior_neg_vec+1e-200);
size_aug_gamma_vec = % contain a constant in the end
options=optimset('Gradobj','off','MaxIter',5000,'Display', 'iter','MaxFunEvals',5000,'TolFun',1e-10); 
lb_my=[zeros(size_aug_gamma_vec,1)];
% pos mle
aug_gamma_vec_pos_star=rand(size_aug_gamma_vec,1); 
[aug_gamma_vec_pos_star,fval,exitflag,output,lambda,grad,hessian] = ...
fmincon('mle_gamma_inference_obj_pos',aug_gamma_vec_pos_star,[],[],[],[],lb_my,[],[],options);  
% neg mle
aug_gamma_vec_neg_star=rand(size_aug_gamma_vec,1);
[aug_gamma_vec_neg_star,fval,exitflag,output,lambda,grad,hessian] = ...
fmincon('mle_gamma_inference_obj_pos',aug_gamma_vec_neg_star,[],[],[],[],lb_my,[],[],options); 

% Bayes_iter_version4.m
g_select=0;
select_index=Bayes_index_mat(fold_index,:);
while(1)    
    % rand    
    tmp_index=select_index(1:(g_select+1)*n_select);
    w_mat_obj= w_mat(tmp_index,:);
    delta_vec_obj = delta_vec(tmp_index,:);
    
    % flip 5 out of 50 -> noise
    index1=find(delta_vec_obj==1);
    index2=find(delta_vec_obj==-1);
    delta_vec_obj(index1(1:min(5,length(index1))))=-1;
    delta_vec_obj(index2(1:min(5,length(index2))))=1;    
     
    pair_train
    save_matrix(gamma_vec','a',gamma_vec_PGDM_fname);
    % 500 for sector; 50 for img
    
    delta =500;
    gamma0=500;
    [var_gamma_mat,mean_gamma_vec]=cal_phi_gamma(delta,gamma0,n_top_eigenK, w_mat_obj,delta_vec_obj);
    % gamma should be nonnegative
    mean_gamma_vec(find(mean_gamma_vec<0))=0;
    mean_gamma_vec_save=[mean_gamma_vec;0]; 
    save_matrix(mean_gamma_vec_save','a',Bayes_gamma_vec_fname);       
    [var_pair_vec,mean_pair_vec]  =cal_covar_dist_pair(mean_gamma_vec,mean_gamma_vec_save,w_mat_obj,var_gamma_mat);
    mean_var_pair_vec(fold_index,g_select+1)=mean(var_pair_vec);   
    % ending condition 
    if g_select>10
        break;
    end 
    g_select=g_select+1;
end 











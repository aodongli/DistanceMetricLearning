a = randperm(size(U_train_mat,2));
a = a(:,1:10); 
U_query_mat_tmp=U_train_mat(:,a); 
U_search_mat_tmp=U_train_mat;
U_search_mat_tmp(:,a)=[];
query_label_vec_tmp = train_label_vec(a);
search_label_vec_tmp = train_label_vec;
search_label_vec_tmp(a)=[];

% for hh =1: 20
%     active_iter_version22_entropy
%     gamma_vec_rand_mat = load(gamma_vec_rand_fname);
%     gamma_vec_rand_mat = gamma_vec_rand_mat(((end-11):end),:);
%     for i = 1: size(gamma_vec_rand_mat,1)
%         ret_prec_cv(:,i) = pair_fold_test_modified_for_ret(gamma_vec_rand_mat(i,:)', U_search_mat_tmp, U_query_mat_tmp,eigen_mat,search_label_vec_tmp,query_label_vec_tmp);    
%     end
% 
%     c = ret_prec_cv(1,:); % rank1 
%     d = [c,100] - [0,c]; 
%     eval(hh) = sum(d>0); 
% end
% [x1, x2] = min(eval); 
% gamma_vec_rand_mat = load(gamma_vec_rand_fname);
% save_matrix(gamma_vec_rand_mat(((x2-1)*12 +1 ):((x2-1)*12+12),:), 'w','c:\find_gamma'); 

gamma_vec_rand_mat = load('C:\KNNN_data\cat_20class\train=0.1\pair\linear-active\gamma_vec_rand.bak');
for hh =1: 20
    gamma_vec_rand_mat_this = gamma_vec_rand_mat(1:12,:);
    gamma_vec_rand_mat(1:12,:)=[];
    for i = 1: size(gamma_vec_rand_mat_this,1)
        ret_prec_cv(:,i) = pair_fold_test_modified_for_ret(gamma_vec_rand_mat_this(i,:)', U_search_mat, U_query_mat_tmp,eigen_mat,search_label_vec,query_label_vec_tmp);    
    end
    c = ret_prec_cv(2,:); % rank1 
    d = [c,100] - [0,c]; 
    eval(hh) = sum(d>0); 
    eval_1(hh)= c(end);
end
[x1, x2] = sort(eval); 
[x3, x4] = sort(-eval_1(x2(1:5)));
x5 = x2(x4);
gamma_vec_rand_mat = load('C:\KNNN_data\cat_20class\train=0.1\pair\linear-active\gamma_vec_rand.bak');
save_matrix(gamma_vec_rand_mat(((x5-1)*12 +1 ):((x5-1)*12+12),:), 'w','c:\find_gamma'); 



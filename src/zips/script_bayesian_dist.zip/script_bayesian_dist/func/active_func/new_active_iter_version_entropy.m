% new_active_iter_version_entropy.m
n_pair=size(w_mat,1); g_select=0;
rand_index_bak  = rand_index(n_pair,n_iter);
active_index_bak = rand_index_bak ; nonb_active_index_bak = rand_index_bak ;
total_index=1:size(w_mat,1);
for g_select =1:n_iter
    n_select_this = n_select; %min(n_select, n_pair-length(rand_index_bak));
    % rand mle    
    w_mat_obj= w_mat(rand_index_bak,:);
    delta_vec_obj = delta_vec(rand_index_bak,:);
    pair_train_plain
    save_matrix(gamma_vec','a',gamma_vec_rand_fname);  
  
    % rand selection
    if g_select <n_iter 
        w_mat_remain_index=total_index;     w_mat_remain_index(rand_index_bak)=[]; 
        select_index_rand = rand_index(size(w_mat_remain_index,2),n_select_this);
        rand_index_bak= [rand_index_bak,  w_mat_remain_index(select_index_rand)];% rand_index is a row     
    end
    % bayes active mle
    if g_select > 1 
        w_mat_obj= w_mat(active_index_bak,:);
        delta_vec_obj = delta_vec(active_index_bak,:);
        pair_train_plain       
    end
    save_matrix(gamma_vec','a',gamma_vec_active_fname);   

    % bayasian learning the distribution of augumented gamma
    if is_plain == 0
        [aug_var_gamma_mat,aug_mean_gamma_vec]=cal_phi_gamma_aug_version(delta,gamma0,n_top_eigen, ...
        w_mat_obj,delta_vec_obj);
        aug_mean_gamma_vec(aug_mean_gamma_vec<0)=0;   % gamma should be nonnegative; round 
        save_matrix(aug_mean_gamma_vec','a',mean_gamma_vec_active_fname); 
    elseif is_plain == 1
        [var_gamma_mat,mean_gamma_vec]=cal_phi_gamma(delta,gamma0,n_top_eigen, w_mat_obj,delta_vec_obj);
        save_matrix(mean_gamma_vec','a',mean_gamma_vec_active_fname);  
    end     
    
    if g_select <n_iter 
        % active selection
        w_mat_remain_index=total_index;   w_mat_remain_index(active_index_bak)=[]; 
        w_mat_remain= w_mat(w_mat_remain_index,:);
        w_mat_remain_index_equ = w_mat_remain_index;    w_mat_remain_index_equ(delta_vec(w_mat_remain_index)==-1)=[];
        w_mat_remain_equ = w_mat(w_mat_remain_index_equ,:);
        
        % inference selection
        % bayes mle active
        % only deal with those equivalent pairs. But we do not know the
        % label when calculating entropy
       % select_index_active = active_index_inference_2(aug_mean_gamma_vec,aug_var_gamma_mat, w_mat_remain_equ, n_select_this);
%     select_index_active=active_index_inference_2_plain(mean_gamma_vec,var_gamma_mat, w_mat_remain_equ, n_select_this);
%     active_index_bak=[active_index_bak,  w_mat_remain_index_equ(select_index_active)];  
      select_index_active=active_index_inference_2_plain(mean_gamma_vec,var_gamma_mat, w_mat_remain, n_select_this);
      active_index_bak=[active_index_bak,  w_mat_remain_index(select_index_active)];  
    end
    
        % non-bayes mle active
    if g_select > 1 
        w_mat_obj= w_mat(nonb_active_index_bak,:);
        delta_vec_obj = delta_vec(nonb_active_index_bak,:);
        pair_train_plain       
    end
    save_matrix(gamma_vec','a',gamma_vec_nonb_active_fname);   
    if g_select <n_iter 
        % nonb active selection      
        w_mat_remain_index=total_index;   w_mat_remain_index(nonb_active_index_bak)=[];    
        w_mat_remain= w_mat(w_mat_remain_index,:);   
        w_mat_remain_index_equ = w_mat_remain_index;    w_mat_remain_index_equ(delta_vec(w_mat_remain_index)==-1)=[];
        w_mat_remain_equ = w_mat(w_mat_remain_index_equ,:);

        % non-bayes mle active
        select_index_nonb_active = active_index_by_abs_dist_mu_plain(gamma_vec,w_mat_remain_equ,n_select_this);
        %select_index_nonb_active = active_index_by_entropy_plain(gamma_vec,w_mat_remain_equ,n_select_this); 
        nonb_active_index_bak=[nonb_active_index_bak,  w_mat_remain_index_equ(select_index_nonb_active)];  
        
       select_index_nonb_active = active_index_by_abs_dist_mu_plain(gamma_vec,w_mat_remain,n_select_this);
       nonb_active_index_bak=[nonb_active_index_bak,  w_mat_remain_index(select_index_nonb_active)];  
    end    
end 









function select_index = active_index_by_entropy_plain(gamma_vec,w_mat,n_select)       

posterior_mat =cal_posterior_naive_plain(gamma_vec,w_mat);
en_pair_vec=cal_entropy_pair_native(posterior_mat);
[i,j] = sort(-en_pair_vec); % largest entropy
select_index =j(1:n_select);
%Bayes_load.m
n_pair= (n_fold_train * n_class)*(n_fold_train * n_class-1);
n_step_each_fold = 1+11;%1+ceil((n_pair-100)/n_select);
% n_active_step_each_fold: number of step for each fold

gamma_vec_PGDM  =load(gamma_vec_PGDM_fname);%each row is gamma_vec
gamma_vec_Bayes =load(Bayes_gamma_vec_fname);           



    
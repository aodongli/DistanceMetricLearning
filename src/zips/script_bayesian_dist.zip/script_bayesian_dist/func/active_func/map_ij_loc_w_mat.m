function loc = map_ij_loc_w_mat(i,j,n_train_img)
x =(1:n_train_img^2); 
x((i-1)*n_train_img + j )=-1;
t=leave_one_out_index(n_train_img); % this will not del -1
x(t)=[];
loc= find(x==-1);

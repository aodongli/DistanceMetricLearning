function l_ij_neg = cal_l_ij_neg(aug_w_mat_obj_pair, aug_gamma_vec, aug_mean_gamma_vec, aug_var_gamma_mat_inv)
a_neg = 1+exp(-aug_w_mat_obj_pair' * aug_gamma_vec);
l_ij_neg = log(a_neg)+ 0.5*(aug_gamma_vec-aug_mean_gamma_vec)'*aug_var_gamma_mat_inv*(aug_gamma_vec-aug_mean_gamma_vec);


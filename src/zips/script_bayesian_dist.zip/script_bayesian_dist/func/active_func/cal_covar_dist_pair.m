function [var_pair_vec,mean_pair_vec,dist_vec]=cal_covar_dist_pair(mean_gamma_vec,gamma_vec,w_mat,var_gamma_mat)
gamma_vec(end)=[];% no b 
dist_vec=gamma_vec'*w_mat'; % a row
mean_pair_vec= mean_gamma_vec'*w_mat';

%%%%%%% sort  by variance 
n_step =100;
n_remain=size(w_mat,1);
var_pair_vec=[];
while(n_remain>0)     
    this_w_mat= w_mat(1:min(n_step,n_remain),:);
    n_remain = n_remain - n_step;
    this_var_pair_vec= diag(this_w_mat* var_gamma_mat*this_w_mat');
    var_pair_vec= [var_pair_vec;this_var_pair_vec];
end
% Bayes_action_this_fold.m
start_fold = (fold_index-1)*n_step_each_fold;

% bayes

gamma_vec_Bayes_this_fold  =  gamma_vec_Bayes((start_fold+1):(start_fold+n_step_each_fold),:);
for j=1:n_step_each_fold        
    [accu_final_Bayes(fold_index,j),prec_rank_mat_Bayes(:,(fold_index-1)*n_step_each_fold+j)]=pair_fold_test(times_Gsigma,0,...
 (gamma_vec_Bayes_this_fold(j,:))', U_train_mat, U_test_mat,eigen_mat,train_label_vec,test_label_vec,leave_one_out_index_t,n_class,eigen_percent);
end
save_matrix(accu_final_Bayes(fold_index,:),'a',accu_Bayes_fname); %each row is a fold
save_matrix(prec_rank_mat_Bayes(1,(fold_index-1)*n_step_each_fold+(1:n_step_each_fold)),...
    'a',prec_Bayes_fname);% each col is a ret_prec, n_step_each_fold cols for each fold
% in the save_file; the first row is rank1 ret
 

% PGDM
gamma_vec_PGDM_this_fold   =  gamma_vec_PGDM((start_fold+1):(start_fold+n_step_each_fold),:);
for j=1:n_step_each_fold
    % pgdm
    [accu_final_PGDM(fold_index,j),prec_rank_mat_PGDM(:,(fold_index-1)*n_step_each_fold+j)]=pair_fold_test(times_Gsigma,0,...        
 (gamma_vec_PGDM_this_fold(j,:))', U_train_mat, U_test_mat,eigen_mat,train_label_vec,test_label_vec,leave_one_out_index_t,n_class,eigen_percent);
end
% save for this fold
% by PGDM
save_matrix(accu_final_PGDM(fold_index,:),'a',accu_PGDM_fname); %each row is a fold
save_matrix(prec_rank_mat_PGDM(1,(fold_index-1)*n_step_each_fold+(1:n_step_each_fold)),...
    'a',prec_PGDM_fname);% each col is a ret_prec, n_step_each_fold cols for each fold
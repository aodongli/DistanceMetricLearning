% Bayes_global_save.m

%bayes
% accu
save_matrix(mean(accu_final_Bayes,1),'w',Bayes_accu_step_mean_over_folds_fname);
% by train 
tmp= vec(prec_rank_mat_Bayes);
tmp1= mat(tmp,n_step_each_fold*size(prec_rank_mat_Bayes,1),n_fold);
save_matrix(mat(mean(tmp1,2),size(prec_rank_mat_Bayes,1),n_step_each_fold),'w',Bayes_prec_step_mean_over_folds_fname);

% PGDM 
save_matrix(mean(accu_final_PGDM,1),'w',PGDM_accu_step_mean_over_folds_fname);
% prec
tmp = vec(prec_rank_mat_PGDM);
tmp1= mat(tmp,n_step_each_fold*size(prec_rank_mat_PGDM,1),n_fold);
save_matrix(mat(mean(tmp1,2),size(prec_rank_mat_PGDM,1),n_step_each_fold),'w',PGDM_prec_step_mean_over_folds_fname);

total_index= 1:size(w_mat,1);
rand_index_bak = rand_pair_bal_choose(delta_vec, n_init_pair); 
active_index_bak = rand_index_bak; 
nonb_active_index_bak = rand_index_bak; 
mean_gamma_active_index_bak = rand_index_bak;
%options = optimset('Gradobj','on', 'LargeScale', 'on', 'MaxIter',5000,'Display', 'iter','MaxFunEvals',50000,'TolFun',1e-4); 
options = optimset('Gradobj','on', 'LargeScale', 'on', 'MaxIter',100,'Display', 'iter','MaxFunEvals',50000,'TolFun',1e-4); 
lb_my = zeros(n_top_eigenK + 1,1);    ub_my = Inf*ones(n_top_eigenK + 1,1);
lb_my_nb = zeros(n_top_eigenK,1);     ub_my_nb = Inf*ones(n_top_eigenK,1);

for inx_iter = 1: n_active_iter 
    global w_mat_obj_1;
    global delta_vec_obj_1;
    global w_mat_obj_2;
    global delta_vec_obj_2;

    if inx_iter > 1
        rand_index_bak = rand_choose_from_remain_n(total_index, rand_index_bak, n_sel);
    end
    w_mat_obj_1 = w_mat(rand_index_bak,:);
    delta_vec_obj_1 = delta_vec(rand_index_bak,:);
    if is_nb == 1,    
        [gamma_vec_rand, fval,exitflag,output,lambda,grad,hessian] = fmincon('pairwise_obj_nb_1', rand(n_top_eigenK, 1), [],[],[],[],lb_my_nb,ub_my_nb,[],options);
    else      
        [gamma_vec_rand,fval,exitflag,output,lambda,grad,hessian] = fmincon('pairwise_obj_1', rand(n_top_eigenK+1, 1),[],[],[],[],lb_my, ub_my, [],options);
    end  
    clear  w_mat_obj_1 delta_vec_obj_1;
    save_matrix(gamma_vec_rand','a',gamma_vec_rand_fname); 

    [var_gamma_mat,mean_gamma_vec] = cal_phi_gamma_feb(delta, gamma0, w_mat(active_index_bak,:), delta_vec(active_index_bak,:), tol_phi_gamma);        
    if is_nb == 1
        mean_gamma_vec(mean_gamma_vec<0)=0;   % nonnegative gamma 
    else
        inx = find(mean_gamma_vec(1:end-1)<0);
        mean_gamma_vec(inx)=0; 
    end
    save_matrix(mean_gamma_vec','a', mean_gamma_vec_fname);      
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % mean_gamma + active_index_by_abs_dist_mu_feb
    [var_gamma_mat_byabs_pair_selection,mean_gamma_vec_byabs_pair_selection] = cal_phi_gamma_feb(delta, gamma0, w_mat(mean_gamma_active_index_bak,:), delta_vec(mean_gamma_active_index_bak,:), tol_phi_gamma);        
    if is_nb == 1
        mean_gamma_vec_byabs_pair_selection(mean_gamma_vec_byabs_pair_selection<0)=0;   % nonnegative gamma 
    else
        inx = find(mean_gamma_vec_byabs_pair_selection(1:end-1)<0);
        mean_gamma_vec_byabs_pair_selection(inx)=0; 
    end
    save_matrix(mean_gamma_vec_byabs_pair_selection','a', mean_gamma_vec_byabs_pair_selection_fname);      
    tmp = complement_inx(total_index, mean_gamma_active_index_bak);
    mean_gamma_active_index_bak =[mean_gamma_active_index_bak, tmp(active_index_by_abs_dist_mu_feb(...
        mean_gamma_vec_byabs_pair_selection, w_mat(tmp, :),min(n_sel, length(tmp))))]; 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    if inx_iter  == 1
        gamma_vec_non_bayes_mle_active = gamma_vec_rand;  
        save_matrix(gamma_vec_non_bayes_mle_active','a', gamma_vec_non_bayes_mle_active_fname);  
        continue;
    end 
    tmp = complement_inx(total_index, active_index_bak);
    active_index_bak= [active_index_bak, tmp(active_index_inference_feb_2(mean_gamma_vec,var_gamma_mat, w_mat(tmp, :), min(n_sel, length(tmp))))];  

   % non-bayes mle active
    tmp = complement_inx(total_index, nonb_active_index_bak);
    nonb_active_index_bak=[nonb_active_index_bak, tmp(active_index_by_abs_dist_mu_feb(gamma_vec_non_bayes_mle_active, w_mat(tmp, :),min(n_sel, length(tmp))))];  
    w_mat_obj_2 = w_mat(nonb_active_index_bak,:);
    delta_vec_obj_2 = delta_vec(nonb_active_index_bak,:);
    if is_nb == 1,    
        [gamma_vec_non_bayes_mle_active,fval,exitflag,output,lambda,grad,hessian] = fmincon('pairwise_obj_nb_2', rand(n_top_eigenK, 1), [],[],[],[],lb_my_nb,ub_my_nb,[],options);
    else      
        [gamma_vec_non_bayes_mle_active,fval,exitflag,output,lambda,grad,hessian] = fmincon('pairwise_obj_2',rand(n_top_eigenK+1,1),[],[],[],[],lb_my,ub_my,[],options);
    end 
    clear  w_mat_obj_2 delta_vec_obj_2  
    save_matrix(gamma_vec_non_bayes_mle_active','a', gamma_vec_non_bayes_mle_active_fname);  
end
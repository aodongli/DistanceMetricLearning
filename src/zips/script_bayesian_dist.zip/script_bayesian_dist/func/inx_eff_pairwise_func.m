function inx_eff = inx_eff_pairwise_func(n1, n2)
inx = my_mat(1:(n1*n2), n1, n2); 
inx_eff = [];
for i = 1: n1
    for j = 1:n2
        if i>j,
            inx_eff = [inx_eff, inx(i,j)];           
        end
    end
end

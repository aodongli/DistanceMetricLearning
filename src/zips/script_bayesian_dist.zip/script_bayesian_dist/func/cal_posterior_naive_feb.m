function posterior_mat = cal_posterior_naive_feb(gamma_vec,w_mat, is_nb)
if is_nb == 1
    gamma_vec_norm = normalize_gamma(gamma_vec);
    dist_vec=gamma_vec_norm'*w_mat'; % a row
    posterior_mat(1,:) = 1./(1 + exp(dist_vec)); % pos
    posterior_mat(2,:) = 1./(1 + exp(-dist_vec)); % neg
else
    mu = gamma_vec(end);
    gamma_vec(end)=[];% no b
    dist_vec=gamma_vec'*w_mat'; % a row
    posterior_mat(1,:) = 1./(1 + exp(dist_vec -mu)); % pos
    posterior_mat(2,:) = 1./(1 + exp(-dist_vec+mu)); % neg
end






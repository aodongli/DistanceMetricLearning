function inx_return = active_index_inference_feb_version4(mean_gamma_vec,var_gamma_mat, w_mat, n_sel)
var_gamma_mat_inv = inv(var_gamma_mat+ 1e-6*eye(size(var_gamma_mat)));
% pos
p_ij_vec_pos = 1./(1+exp(-w_mat*mean_gamma_vec));
q_ij_vec_pos = p_ij_vec_pos.*(1-p_ij_vec_pos);
% neg
p_ij_vec_neg = -exp(-w_mat*mean_gamma_vec)./(1+exp(-w_mat*mean_gamma_vec));
q_ij_vec_neg = p_ij_vec_neg.*(-1-p_ij_vec_neg);

entropy_pair_vec = [];
for i= 1:size(w_mat,1)      
    w_mat_pair = (w_mat(i,:))'; % a col
    % compute gamma_vec_star
    cc_inv = inv(q_ij_vec_pos(i)*w_mat_pair*w_mat_pair' + var_gamma_mat_inv+ 1e-6*eye(size(var_gamma_mat)));
    gamma_vec_star_pos  = mean_gamma_vec - p_ij_vec_pos(i)*cc_inv*w_mat_pair;
    % compute q_ij_star
    a = gamma_vec_star_pos'*w_mat_pair;
    q_ij_star_pos  = exp(-a)/((exp(-a)+1)^2);
    % cal l_ij_star
    l_ij_star_pos =log(1+exp(w_mat_pair'*mean_gamma_vec)) + p_ij_vec_pos(i)^2/2* w_mat_pair' *cc_inv*w_mat_pair;
    % cal posterior
    post_pos = exp(-l_ij_star_pos)*sqrt(det(eye(size(var_gamma_mat)) + q_ij_star_pos*var_gamma_mat*w_mat_pair*w_mat_pair'));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % compute gamma_vec_star
    cc_inv = inv(q_ij_vec_neg(i)*w_mat_pair*w_mat_pair' + var_gamma_mat_inv+ 1e-6*eye(size(var_gamma_mat)));
    gamma_vec_star_neg  = mean_gamma_vec - p_ij_vec_neg(i)*cc_inv*w_mat_pair;
    % compute q_ij_star
    a = gamma_vec_star_neg'*w_mat_pair;
    p_ij_tmp = -exp(-w_mat_pair'*gamma_vec_star_neg)/(1+exp(-w_mat_pair'*gamma_vec_star_neg));
    q_ij_star_neg = p_ij_tmp*(-1-p_ij_tmp);
    % cal l_ij_star
    l_ij_star_neg =log(1+exp(-w_mat_pair'*mean_gamma_vec)) + p_ij_vec_neg(i)^2/2* w_mat_pair' *cc_inv*w_mat_pair;
    % cal posterior 
    post_neg = exp(-l_ij_star_neg)*sqrt(det(eye(size(var_gamma_mat)) + q_ij_star_neg*var_gamma_mat*w_mat_pair*w_mat_pair'));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % compute entropy
    % renormalize
    a = post_pos+post_neg +1e-10;
    post_pos = post_pos/a;
    post_neg = post_neg/a;    
    % entropy 
    entropy_pair_vec =[entropy_pair_vec, -post_pos*log(1e-10+post_pos)-post_neg*log(1e-10+post_neg)];
end
% select pairs with largest entropy_pair
[x1,x2] = sort(-entropy_pair_vec);
inx_return = x2(1:n_sel); 
function a = complement_inx(a, b)
a(b)=[];
function w_mat = cal_w_mat_feb(U_mat1,U_mat2, eigen_mat, inx_eff, is_nb)

[n_dim,n1]=size(U_mat1);
[n_dim,n2]=size(U_mat2);
left_sub=repmat(U_mat1', n2, 1);
right_sub=(my_mat((repmat(U_mat2',1,n1))',n_dim,n1*n2))';
diff_mat= left_sub-right_sub; 
w_mat = (diff_mat*eigen_mat).^2;
w_mat = w_mat(inx_eff, :);
if is_nb == 0
    w_mat = [w_mat, -ones(size(w_mat, 1), 1)];
end



function sel_inx = active_index_by_abs_dist_mu_feb(gamma_vec, w_mat, n_sel)
dist_vec = gamma_vec'*w_mat'; 
[i1,i2] = sort(dist_vec); 
sel_inx = i2(1:n_sel);
function mean_std_feb(x, n_active_iter, fname_mean, fname_std, n_run, n_sub_run)
n_rank = size(x,1);
y = [];
std_y =[];
for i = 1 : n_rank
    z = my_mat(x(i, :),  n_active_iter* n_sub_run, n_run);
    tmp = [];
    for j  = 1: n_run
        tmp = [tmp, mean(my_mat(z(:,j), n_active_iter, n_sub_run), 2)];
    end
    y = [y, mean(tmp, 2)];
    std_y = [std_y, std(tmp,0,2)];
end
save_matrix(y', 'w', fname_mean);
save_matrix(std_y' ,'w', fname_std);

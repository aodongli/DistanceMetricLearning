function [f,g]=pairwise_obj_2(gamma_vec)
global w_mat_obj_2;
global delta_vec_obj_2;

C=0; % C must be nonnegative, a regulizer; if set C to be 0, no influence
tmp=delta_vec_obj_2.*(w_mat_obj_2 * gamma_vec);
index_neg=find(tmp<0);
tmp_max=tmp; 
tmp_max(index_neg)=0; % find the max with 0 cell by cell 
f=sum(log(exp(-tmp_max)./(exp(-tmp_max)+exp(tmp-tmp_max))+1e-200)); 
f=f-C*sum(gamma_vec(1:end-1).^2);
f=-f;

if nargout > 1      
  tmp2= delta_vec_obj_2.*( exp(tmp-tmp_max)./(exp(-tmp_max)+exp(tmp-tmp_max)));
%   g=- w_mat_obj_2(:,(1:end-1))' * tmp2;
%   g= g - 2*C*gamma_vec(1:end-1);
%   g_end=sum(sum(tmp2));
%   g=[g;g_end];
    g= - w_mat_obj_2' * tmp2;
    g= g - 2*C*gamma_vec;
    g=-g;
end



Thanks for using this package for Bayesian Active Distance Metric Learning. 

1.  ./func directory gives the major functions 
2.  ./example directory example_corel_img_5class_n_init_20_8.m  
gives you an example on how to use these functions
3.  The gamma vector learnt by the four methods 
BAYES+VAR
BAYES+ACT
MLE+ACT
MLE+RAND
(see Figure 2  in the paper availabel at 
http://www.cse.msu.edu/~yangliu1/uai2007_bayesian.pdf)
is named in the matlab implemenation as the following: 
mean_gamma_vec_byabs_pair_selection
mean_gamma_vec
gamma_vec_non_bayes_mle_active
gamma_vec_rand

The denotation of others variables follows the same fashion. 

4. the file load_data_by_inx_rand.m 
basically is to load the random index for the training data. 
inx_mat_query, inx_mat_search, inx_mat_train are the randomly 
generated index, which are stored in matrix over different runs. 
inx_run counts which random run it is.

Having not cleaned it up completely,  please let me know for any problems in running it. 








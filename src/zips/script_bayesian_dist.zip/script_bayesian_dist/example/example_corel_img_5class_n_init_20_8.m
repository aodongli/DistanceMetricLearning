load .\example\corel_5_class.mat
dir_name = '.\example\20_8\';
dir_run_inx = '.\example\50\';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta = 0.01; gamma0 = 2;
tol_phi_gamma = 1e-8;
is_nb  = 1; 
n_init_pair = 20;
n_active_iter = 10;  
n_sel = 20; 
n_query_percent = 0.2;
n_train_percent = 0.1;
n_run = 10;
n_sub_run = 10;
KK_knn = 1:20;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
inx_mat_query = load([dir_run_inx, 'inx_', num2str(n_query_percent), '_query']);
inx_mat_search = load([dir_run_inx, 'inx_', num2str(1 - n_query_percent), '_search']);
inx_mat_train = load([dir_run_inx, 'inx_', num2str(n_train_percent), '_train']);
bayes_train_feb_gamma
rank_id = 5; nn = 20;
bayes_test_feb_gamma_2